import GameTableGenerator from "./main/GameTableGenerator.js";
export default class Main {

    #gameTableGenerator
    #mainDiv

    constructor(mainDiv) {

        this.#mainDiv = mainDiv

        console.log("mainDiv: ", mainDiv);

        let gameTableGeneratorDiv = document.createElement("div")
        this.#mainDiv.appendChild(gameTableGeneratorDiv)
        let gameDiv = document.createElement("div")
        this.#mainDiv.appendChild(gameDiv)


        this.#gameTableGenerator = new GameTableGenerator(gameTableGeneratorDiv)
    }


}