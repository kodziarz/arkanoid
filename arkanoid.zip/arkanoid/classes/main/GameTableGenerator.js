import BricksPanel from "./gameTableGenerator/BricksPanel.js"
import DrawBoard from "./gameTableGenerator/DrawBoard.js"
export default class GameTableGenerator {

    #mainDiv
    #bricksPanel
    #drawBoard

    constructor(mainDiv) {

        this.#mainDiv = mainDiv

        let bricksPanelDiv = document.createElement("div")
        this.#mainDiv.appendChild(bricksPanelDiv)
        this.#bricksPanel = new BricksPanel(bricksPanelDiv)

        this.#drawBoard = new DrawBoard()
    }

    #generateTable = () => {

    }
}