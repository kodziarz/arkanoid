export default class Brick {

    static SOURCE_ELEMENT = document.getElementById("img")
    static WIDTH = 20
    static HEIGHT = 30

    #DOMElement
    #context
    #sourceX
    #sourceY
    #sourceWidth
    #sourceHeight

    constructor(sourceX, sourceY, sourceWidth, sourceHeight) {
        this.#DOMElement = document.createElement("canvas")
        this.#context = this.#DOMElement.getContext("2d")

        this.#sourceX = sourceX
        this.#sourceY = sourceY
        this.#sourceWidth = sourceWidth
        this.#sourceHeight = sourceHeight

        this.#context.drawImage(
            Brick.SOURCE_ELEMENT,
            this.#sourceX,
            this.#sourceY,
            this.#sourceWidth,
            this.#sourceHeight,
            0,
            0,
            Brick.WIDTH,
            Brick.HEIGHT)
    }
}