export default class BricksPanel {

    #bricksDiv
    #bricks

    constructor(brickDiv) {
        this.#bricksDiv = brickDiv

        let canvas = document.createElement("canvas")
        this.#bricksDiv.appendChild(canvas)
        let ctx = canvas.getContext("2d")
        let img = document.getElementById("img")
        ctx.drawImage(img, 30, 83, 15, 7, 0, 0, 20, 10)
    }

    #generateBricksToChoose = () => {
        const sx = 30
        const sy = 83
        const sw = 15
        const sh = 7
        const dw = 20
        const dh = 10

        for (let i = 0; i < 8; i++) {

        }
    }
}