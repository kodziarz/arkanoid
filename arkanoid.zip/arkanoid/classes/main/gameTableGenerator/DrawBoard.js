export default class DrawBoard {

    #boardDiv

    constructor(boardDiv) {
        this.#boardDiv = boardDiv
    }



}